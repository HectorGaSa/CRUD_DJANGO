from django.contrib import admin
from django.urls import path, include
from HiperNova.views import user_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/users/', include('HiperNova.urls.user_urls')),
    path('api/users/<int:id>/change', user_views.actualizarUsuario, name='actualizar_usuario'),
    path('api/users/<int:id>/delete', user_views.borrarUsuario, name='borrar_usuario'),
    path('api/users/', user_views.listUsers, name="listUsers"),
]