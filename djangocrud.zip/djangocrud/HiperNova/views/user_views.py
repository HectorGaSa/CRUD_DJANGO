#code for user_views.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from rest_framework.exceptions import AuthenticationFailed
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from HiperNova.serializers import UserSerializer, UserSerializerWithToken
from rest_framework_simplejwt.views import TokenObtainPairView
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class MyTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        try:
            data = super().validate(attrs)
            serializer = UserSerializerWithToken(self.user).data
            for k, v in serializer.items():
                data[k] = v
            username = self.user.username
            print(f'Inicio de sesion exitoso para el usuario: {username}')
            return data
        except AuthenticationFailed:
            print('Intento de inicio de sesion fallido')
            raise

class MyTokenObtainPairView(TokenObtainPairView):
    serializer_class = MyTokenObtainPairSerializer

@api_view(['GET'])
def listUsers(request):
    try:
        users = User.objects.all()
        serializer = UserSerializer(users, many=True)
        return Response(serializer.data)
    
    except Exception as e:
        print(f'Error al obtener usuarios: {str(e)}.')
        message = {'detail': 'Error al obtener usuarios'}
        return Response(message, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def registerUser(request):
    data = request.data
    email = (data['email']).strip().lower()
    username = (data['username']).strip()
    password = (data['password']).strip()        

    try:
        user = User.objects.create(
        first_name=username,
        username=username,
        email=email,
        password=make_password(password)
        )
        serializer = UserSerializerWithToken(user, many=False)
        print(f'Usuario registrado con éxito: {email}.')
        return Response(serializer.data)

    except Exception as e:
        print(f'Error al registrar usuario: {str(e)}.')
        message = {'detail': 'La información proporcionada no es válida, revisa el formato de tu correo'}
        return Response(message, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
def borrarUsuario(request, id):
    if request.method != 'DELETE':
        return Response({'detail': 'Método no permitido'}, status=status.HTTP_405_METHOD_NOT_ALLOWED)

    if not (id):
        message = {'detail': 'La información proporcionada no es válida'}
        return Response(message, status=status.HTTP_400_BAD_REQUEST)

    try:
        user = User.objects.get(pk=id)
        user.delete()
        serializer = UserSerializerWithToken(user, many=False)
        return Response(serializer.data)        
    
    except User.DoesNotExist:
        message = {'detail': 'Usuario no encontrado'}
        return Response(message, status=status.HTTP_404_NOT_FOUND)

    except Exception as e:
        print(f'Error al borrar el usuario: {str(e)}.')
        message = {'detail': 'Error interno del servidor'}
        return Response(message, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['PUT'])
def actualizarUsuario(request, id):
    data = request.data
    email = (data['email']).strip().lower()
    username = (data['username']).strip()
    password = (data['password']).strip() 

    if not (username and password and email):
        message = {'detail': 'La información proporcionada no es válida, revisa el formato de tu correo'}
        return Response(message, status=status.HTTP_400_BAD_REQUEST)
    
    try:
        user = User.objects.get(pk=id)
        user.first_name=username
        user.username=username
        user.email=email
        user.password=make_password(password)
        user.save()

        serializer = UserSerializerWithToken(user, many=False)
        return Response(serializer.data)
    
    except User.DoesNotExist:
        message = {'detail': 'Usuario no encontrado'}
        return Response(message, status=status.HTTP_404_NOT_FOUND)

    except Exception as e:
        print(f'Error al modificar el usuario: {str(e)}.')
        message = {'detail': 'Error interno del servidor'}
        return Response(message, status=status.HTTP_500_INTERNAL_SERVER_ERROR)